import time
import os

def starting(word):
    print(f'{word}')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}.')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}..')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}...')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}.')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}..')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}...')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}.')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}..')
    time.sleep(0.8)
    os.system('cls')

    print(f'{word}...')
    time.sleep(0.8)
    os.system('cls')

    
    