# Discontinued for now since project won't be too beneficial since it is too simple

from loadingscreen import loading_screen
from charactersheet import character_sheet


loading_screen()

character_sheet()
