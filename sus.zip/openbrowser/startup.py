#! python3
# This program will run all my startup browser pages 

import webbrowser

webbrowser.open('https://www.linkedin.com/in/ahanaf-zaman-290364217/')
webbrowser.open('http://clashofclansforecaster.com/')
webbrowser.open('https://twitter.com/home')
webbrowser.open('https://www.reddit.com/r/ClashOfClansLeaks/')
webbrowser.open('https://stackoverflow.com/')